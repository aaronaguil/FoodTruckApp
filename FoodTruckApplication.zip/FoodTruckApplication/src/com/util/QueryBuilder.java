package com.util;

public interface QueryBuilder {

	public String buildQuery();
}

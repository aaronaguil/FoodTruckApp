package com.util;

public enum QueryBuilderType {

	CurrentTimeAndDay
}
